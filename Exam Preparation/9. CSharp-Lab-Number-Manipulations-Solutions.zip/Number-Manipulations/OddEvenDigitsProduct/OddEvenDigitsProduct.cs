﻿using System;

namespace OddEvenDigitsProduct
{
    class OddEvenDigitsProduct
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            int evenProduct = 1;
            int oddProduct = 1;

            while (n > 0)
            {
                int digit = n % 10;
                if (digit % 2 == 0)
                {
                    evenProduct *= digit;
                }
                else
                {
                    oddProduct *= digit;
                }

                n /= 10;
            }

            Console.WriteLine("Even: " + evenProduct);
            Console.WriteLine("Odd: " + oddProduct);
        }
    }
}
