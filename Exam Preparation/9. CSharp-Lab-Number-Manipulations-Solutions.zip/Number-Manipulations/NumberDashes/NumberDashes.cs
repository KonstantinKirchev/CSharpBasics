﻿using System;

namespace NumberDashes
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            int lengthCount = 0;
            int originalNum = n;

            // get digits count
            while (originalNum > 0)
            {
                lengthCount++;
                originalNum /= 10;
            }

            originalNum = n;
            int count = lengthCount - 1;
            string output = "";
            while (count >= 0)
            {
                int devisor = (int)Math.Pow(10, count);
                int result = (originalNum / devisor) % 10;
                output += result + (count != 0 ? "-" : "");
                count--;
            }

            Console.WriteLine(output);
        }
    }
}
