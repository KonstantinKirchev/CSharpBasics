﻿using System;

namespace SumOfDigits
{
    class SumOfDigits
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            int number = n;
            int sum = 0;
            while (number > 0)
            {
                int digit = number % 10;
                sum += digit;
                number /= 10;
            }

            /* same as while loop
            for ( ; number > 0; number /= 10)
            {
                int digit = number % 10;
                sum += digit; 
            }
            */
            Console.WriteLine(sum);
        }
    }
}
