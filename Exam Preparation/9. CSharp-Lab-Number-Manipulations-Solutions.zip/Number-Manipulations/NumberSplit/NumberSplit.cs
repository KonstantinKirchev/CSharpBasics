﻿using System;

namespace NumberSplit
{
    class NumberSplit
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            int original = n;
            int count = 0;
            while (original > 0)
            {
                count++;
                original /= 10;
            }

            int rightCount = count / 2;
            int leftCount = count - rightCount;

            int divisor = (int)Math.Pow(10, rightCount);

            int rightPart = n % divisor;
            int leftPart = n / divisor;

            int leftSum = 0;
            while (leftPart > 0)
            {
                int digit = leftPart % 10;
                leftSum += digit;
                leftPart /= 10;
            }
            Console.WriteLine(leftSum);

            int rightSum = 0;
            while (rightPart > 0)
            {
                int digit = rightPart % 10;
                rightSum += digit;
                rightPart /= 10;
            }
            Console.WriteLine(rightSum);

            if (leftSum > rightSum)
            {
                Console.WriteLine("Left part is greater.");
            }
            else 
            {
                if (rightSum > leftSum)
                {
                    Console.WriteLine("Right part is greater.");
                }
                else
                {
                    Console.WriteLine("Equal");
                }
            }
        }
    }
}
