﻿using System;

namespace LastDigitOfNumber
{
    class LastDigitOfNumber
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            int lastDigit = n % 10;
            int lastThreeDigits = n % 1000;

            Console.WriteLine(lastDigit);
            Console.WriteLine(lastThreeDigits);
        }
    }
}
