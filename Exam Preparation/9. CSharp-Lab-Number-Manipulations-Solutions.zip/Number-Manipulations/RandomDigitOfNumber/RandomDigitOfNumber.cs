﻿using System;

namespace RandomDigitOfNumber
{
    class RandomDigitOfNumber
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int p = int.Parse(Console.ReadLine());

            int divider = (int)Math.Pow(10, p - 1);
            int result = (n / divider) % 10;

            Console.WriteLine(result);
        }
    }
}
