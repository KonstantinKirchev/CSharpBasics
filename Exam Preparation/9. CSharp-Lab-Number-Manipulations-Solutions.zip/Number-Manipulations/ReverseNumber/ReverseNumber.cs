﻿using System;

namespace ReverseNumber
{
    class ReverseNumber
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            int number = n;
            string output = "";
            while (number > 0)
            {
                int digit = number % 10;
                output += digit;
                number /= 10;
            }
            Console.WriteLine(output);
        }
    }
}
